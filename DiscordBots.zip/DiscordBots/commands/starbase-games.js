const Discord = require('discord.js')

module.exports = {

    name: 'starbase-games',
    description: "Jebediah Commands",
    async execute(message, args, Discord) {
        const embed1 = new Discord.MessageEmbed()
    .setColor('0099ff')
    .setTitle('Starbase Simulator')
    .setURL('https://ashtorak.itch.io/starbase-simulator')
    .setAuthor(`Requested by ${message.author.tag}`)
    .setDescription(`"Starbase Simulator" is a simulation game made by Ashtorak that simulates the consrtuction of starship "SN20, B4", in this game you can stack, fly and land Starship and Superheavy, made using real world images, as well as popular models from KSP mods, recommended by TheSpaceAce`)
    .setThumbnail('https://i.imgur.com/evIXF1N.png')
    .setImage('https://i.imgur.com/zOpYVZ0.png')
    .setTimestamp()
    .setFooter('Please notify TheSpaceAce#2107 of any other starbase games!')
    
const embed2 = new Discord.MessageEmbed()
    .setColor('0099ff')
    .setTitle('Road To Mars')
    .setURL('https://roadtomars.page/')
    .setDescription('Road to mars is an immersive, interactive starbase/starship game. Made by Alexandre Roth, with help from others in the space community. Inside you can stack, launch, fly, land, and many more with starships, it is more immerse and realistic than Starbase simulator, and is paid on a montly subscription, compared to starbase simulator being free, it is not meant for low end pcs. recommended by TheSpaceAce :)')
    .setThumbnail('https://i.imgur.com/ojdINss.png')
    .setImage('https://i.imgur.com/VOvEC5D.png')
    .setTimestamp()
    .setFooter('Please notify TheSpaceAce#2107 of any other starbase games!')
    

message.channel.send({embed: embed1})
message.channel.send({embed: embed2})
        
    
    }

}
