const Discord = require('discord.js');


module.exports = {
    name: "search",
    description: "Gives the wanted google search",

    async execute(message, args, Discord){
        let msglink = args.join('+') 
        let msg = args.join(' ')

if(!args[0]) return message.channel.send('Please give me a query to search!')

        let embed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle(`Here is the ${msg} google search!`)
        .setDescription(`Here you go, the [${msg}](https://www.google.com/search?q=${msglink}) Google search!`)
        .setFooter('Pleas note that this command is in beta, there are bound to be bugs!')

        message.channel.send(embed)
    }
}