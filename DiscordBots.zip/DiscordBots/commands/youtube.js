module.exports = {
    name: 'youtube',
    description: "this will show a link to my youtube channel!",
    execute(message, args, Discord){
        const embed  = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle("TheSpaceAce's Youtube Channel")
        .setURL('https://www.youtube.com/channel/UCMldAiUDEt53cUo-Qk6F3Rw')
        .setImage('https://i.imgur.com/fzLjN2R.png')
        .setTimestamp()

        message.channel.send(embed)
    }
}