module.exports = {
    name: 'youtube',
    description: "this will show a link to my youtube channel!",
    execute(message, args){
        message.channel.send('https://www.youtube.com/channel/UCMldAiUDEt53cUo-Qk6F3Rw')
    }
}