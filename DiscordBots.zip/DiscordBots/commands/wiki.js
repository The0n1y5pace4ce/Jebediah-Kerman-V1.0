const Discord = require('discord.js'); // defining Discord


module.exports = {
    name: "wiki",
    description: "Gives the wanded wikipedia article",

    async execute(message, args, Discord){
        let msglink = args.join('_') 
        let msg = args.join(' ')

if(!args[0]) return message.channel.send('Please give me a wiki article to search')

        let embed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle(`Here is the ${msg} wiki!`)
        .setDescription(`Here you go, the [${msg}](https://en.wikipedia.org/wiki/${msglink}) wiki!`)
        .setFooter('Pleas note that this command is in beta, there are bound to be bugs!')

        message.channel.send(embed)
    }
}