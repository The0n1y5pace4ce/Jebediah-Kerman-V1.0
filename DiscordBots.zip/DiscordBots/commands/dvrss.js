module.exports = {
    name: 'dvrss',
    description: "this will show a rss delta v map!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Real Solar System Delta V Map (KSP)')
        .setImage('https://media.discordapp.net/attachments/889064624979324959/921996010866241546/RSS_Delta-V_Map.png')
        .setTimestamp()

        message.channel.send(embed)
    }
}