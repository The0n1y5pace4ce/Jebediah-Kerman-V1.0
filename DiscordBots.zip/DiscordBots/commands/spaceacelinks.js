module.exports = {
    name: 'spaceacelinks',
    description: "Links to my socials",
    execute(message, args, Discord) {
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0000FF')
        .setTitle('Links To My Socials!')
        .setDescription('These are the links to my accounts!')
        .addFields(
            {name: 'Youtube', value: 'https://www.youtube.com/channel/UCMldAiUDEt53cUo-Qk6F3Rw'},
            {name: 'Twitter', value: 'https://twitter.com/TheOnlySpaceAce'},
            {name: 'Github', value: 'https://github.com/The0n1y5pace4ce'},
            {name: 'Reddit', value: 'https://www.reddit.com/user/The_only_Space_Ace'},
            {name: 'Spotify', value: 'https://open.spotify.com/user/5hhxarpp66l52ddetdmn98m3j'},
            {name: 'Steam', value: 'https://steamcommunity.com/id/The-Only-space-ace/'},
            {name: 'Kerbal Space Program Forums', value: 'https://forum.kerbalspaceprogram.com/index.php?/profile/214146-the_only_spaceace/'},
        )

        message.channel.send(newEmbed);
    }

}