module.exports = {
    name: 'invite',
    description: "this will give you an invite to my discord server!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Permanent Server Invite')
        .setURL('https://discord.gg/AM787M44au')
        .setTimestamp()

        message.channel.send(embed)
    }
}