const Discord = require('discord.js')

module.exports = {
    name: 'djs',
    description: "links to discord.js documentation",
    execute(message, args, Discord){
        const djsEmbed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Discord.js')
        .setURL('https://discord.js.org/#/')
        .setAuthor(`Requested by ${message.author.tag}`)
        .setDescription('Discord.js is a powerful api allowing you to create and run a discord bot using javascript. Discord.js is what Jebediah Kerman runs on.')
        .setThumbnail('https://i.imgur.com/KhyfNvm.png')
        .setImage('https://i.imgur.com/mdRN5WI.png')
        .setTimestamp()

        message.channel.send(djsEmbed)
    }
}