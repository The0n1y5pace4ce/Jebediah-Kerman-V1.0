module.exports = {
    name: 'spaceacemods',
    description: "this will give you an invite to my discord server!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Mods Made By TheSpaceAce#2107')
        .setURL('https://forum.kerbalspaceprogram.com/index.php?/topic/205722-thespaceaces-mods/')
        .setTimestamp()
        
        message.channel.send(embed)
    }
}