module.exports = {
    name: 'spaceacemods',
    description: "this will give you an invite to my discord server!",
    execute(message, args){
        message.channel.send('https://forum.kerbalspaceprogram.com/index.php?/topic/205722-thespaceaces-mods/')
    }
}