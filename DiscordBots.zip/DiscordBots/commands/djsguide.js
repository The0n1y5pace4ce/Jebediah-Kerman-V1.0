module.exports = {
    name: 'djsguide',
    description: "links to discord.js documentation",
    execute(message, args, Discord){
        const djsguideEmbed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Discord.js Guide')
        .setURL('https://discordjs.guide/')
        .setDescription('The Discord.js guide contains everything needed to create your own bot using Discord.js!')
        .setImage('https://i.imgur.com/CcqsOCr.png')
        .setTimestamp()

        message.channel.send(djsguideEmbed);
    }
}