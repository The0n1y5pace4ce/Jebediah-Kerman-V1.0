module.exports = {
    name: 'unmute',
    description: 'Mutes members',
    execute(message, args){

        let role = message.guild.roles.cache.find(r => r.name === 'Moderator');

        if(message.member.roles.cache.has('868984164131667978')){
            const memberTarget = message.mentions.members.first();
            const role = memberTarget.guild.roles.cache.find(role => role.name === 'Flat earther');
            memberTarget.roles.remove(role);
            message.channel.send('User unmuted')
        }
        else{
            message.channel.send('You do not have permission to mute members');
        }
    }
}