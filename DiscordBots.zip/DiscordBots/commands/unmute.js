module.exports = {
    name: 'unmute',
    description: 'Mutes members',
    execute(message, args){

        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('You cant use that!')
            const memberTarget = message.mentions.members.first();
            const role = memberTarget.guild.roles.cache.find(role => role.name === 'Muted');
            memberTarget.roles.remove(role);
            message.channel.send('User unmuted')
        }
        
    }
