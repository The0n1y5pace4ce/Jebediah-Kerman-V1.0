module.exports = {
    name: 'dvksrss',
    description: 'Shows a KSRSS delta v map',
    execute(message, args, Discord){
        const embed  = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('KSRSS Delta V Map (KSP)')
        .setImage('https://media.discordapp.net/attachments/889064624979324959/921995927697358848/dvksrss.png')
        .setTimestamp()

        message.channel.send(embed)
    }   
}