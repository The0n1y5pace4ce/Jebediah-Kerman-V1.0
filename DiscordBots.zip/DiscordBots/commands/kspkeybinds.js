module.exports = {
    name: 'kspkeybinds',
    description: "this will the KSP ketbinds",
    execute(message, args){
        message.channel.send('https://imgur.com/kqQPC1j')
    }
}