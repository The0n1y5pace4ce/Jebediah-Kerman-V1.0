module.exports = {
    name: 'kspkeybinds',
    description: "this will the KSP ketbinds",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Keybinds For Kerbal Space Program (without changing it manually)')
        .setImage('https://i.imgur.com/kqQPC1j.png')
        .setTimestamp()

        message.channel.send(embed)

    }
}