module.exports = {
    name: 'dvstock',
    description: "this will show a stock delta v map!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Delta V Map For The Stock KSP System')
        .setImage('https://media.discordapp.net/attachments/889064624979324959/921994810968137728/DV_stock.png?width=797&height=1127')
        .setTimestamp()

        message.channel.send(embed)
    }
}