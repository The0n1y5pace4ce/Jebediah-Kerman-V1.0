module.exports = {
    name: 'help-utility',
    description: "idk",
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Jebediah Utitity Commands')
        .setDescription('Utility commands for Jebediah Kerman')
        .addFields(
            {name: 'embed <title> <Color (hex)> <content>', value: 'Allows you to make embeds!'},
            {name: 'weather <country/city>', value: 'Allows you to see what the weather is like anywhere in the world!'},
            {name: 'avatar', value: 'Shows you your avatar'},
            {name: 'random-urban', value: 'sends a random urban dictionary article'},
            {name: 'advice', value: 'GIves you some good advice!'},
            {name: 'urban', value: 'Sends an urban dictionary article based on your search'},
            {name: 'wiki', value: 'Search the wikipedia website (WIP)'},
            {name: 'search', value: 'Searches google!'},
            {name: 'poll', value: 'Sends a poll!'},
            {name: 'reverse', value: 'Reverses the sent text!'},
            {name: 'serverinfo', value: 'Shows the info of the server!'},
            {name: 'userinfo', value: 'Shows info of the selected user'},
            {name: 'latency', value: 'Shows the latency of the bot'},
            {name: 'changelog', value: 'Shows the changelogs for jebediah'},
        )

        message.channel.send(newEmbed);
    }
}