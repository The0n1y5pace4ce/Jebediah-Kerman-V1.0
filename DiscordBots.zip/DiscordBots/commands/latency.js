module.exports = {
  name: 'latency',
  description: `Displays the bot's current latency in ms.`,
  usage: 'ping',
  async execute(message, args) {
    let msg = await message.channel.send('Pinging...');
    msg.edit(`Response Latency: ${Math.floor(msg.createdTimestamp - message.createdTimestamp)} ms`);
  }
}