module.exports = {
    name: 'help',
    description: "Jebediah Commands",
    execute(message, args, Discord) {
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Error, please enter a help query')
        .setDescription('Please select a command from the list below')
        .addFields(
            {name: 'help-fun', value: 'A list of the fun/games commands'},
            {name: 'help-ksp', value: 'KSP help commands'},
            {name: 'help-moderation', value: ' A list of moderation commands that only work for mods'},
            {name: 'help-utility', value: 'A list of useful commands'},
            {name: 'help-other', value: 'A list of other commands'}

        )

        message.channel.send(newEmbed);
    }

}