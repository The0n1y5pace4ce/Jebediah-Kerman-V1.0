module.exports = {
    name: 'help-ksp',
    description: "Help commands od jebediah kerman relating to KSP",
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Jebediah KSP Commands')
        .setDescription('Help commands of jebediah kerman relating to KSP')
        .addFields(
            {name: 'dvjnsq', value: 'Shows a delta v map for the KSP mod JNSQ'},
            {name: 'dvrss', value: 'Shows a delta v map for the KSP mod RSS'},
            {name: 'dvksrss', value: 'Shows a Delta V Map for the KSRSS system'},
            {name: 'dvstock', value: 'Shows a delta v map for the stock KSP system'},
            {name: 'dvgpp', value: 'Shows a galileo planet pack delta v map'},
            {name: 'kspkeybinds', value: 'Shows the KSP keybinds, on a keyboard'},
            {name: 'kspforums', value: 'Sends a link to the kerbal space program forums'},
            {name: 'kspmods', value: 'Sends a link to the kerbal space program modding sites'},
            {name: 'addonsbyace', value: 'Sends the links to all addons for KSP made by TheSpaceAce'},
            {name: 'vismodsdecide', value: 'Gives you advice on what visual mods to use for KSP'},
            {name: 'spaceacemods', value: 'Sends a Kerbal Space Program forum link with a list of my visual mods'},
        )

        message.channel.send(newEmbed);
    }
}