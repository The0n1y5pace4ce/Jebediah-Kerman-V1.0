module.exports = {
    name: 'kspforums',
    description: "this will give you an invite to my discord server!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Kerbal Space Program Forums')
        .setURL('https://forum.kerbalspaceprogram.com')
        .setImage('https://i.imgur.com/UmK9Egi.png')
        .setTimestamp()

        message.channel.send(embed)
    }
}