module.exports = {
    name: 'kspforums',
    description: "this will give you an invite to my discord server!",
    execute(message, args){
        message.channel.send('https://forum.kerbalspaceprogram.com')
    }
}