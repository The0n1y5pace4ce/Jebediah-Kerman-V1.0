module.exports = {
    name: 'dvjnsq',
    description: "this will show a jnsq delta v map!",
    execute(message, args, Discord){
        const embed  = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('JNSQ Planet Pack Delta V Map (KSP)')
        .setImage('https://media.discordapp.net/attachments/889064624979324959/921995834676101120/JNSQ_DV-01.png?width=1456&height=1128')
        .setTimestamp()

        message.channel.send(embed);
    }
}