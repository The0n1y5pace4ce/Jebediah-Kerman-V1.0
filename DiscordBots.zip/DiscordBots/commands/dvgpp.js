module.exports = {
    name: 'dvgpp',
    description: "this will show a gpp delta v map!",
    execute(message, args, Discord){
        const embed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('Galileos Planet Pack Delta V Map (KSP)')
        .setImage('https://media.discordapp.net/attachments/883250115769434132/921995498662015017/GPP_dVmap.png')
        .setTimestamp()

        message.channel.send(embed)
    }
}