module.exports = {
    name: 'help-other',
    description: "none",
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Jebediah Other Commands')
        .setDescription('Other commands of Jebediah Kerman')
        .addFields(
            {name: 'Jebediah Kerman Prefix', value: 'The prefix for Jebediah Kerman is "#"'},
            {name: 'invite', value: 'Sends an invite to my server'},
            {name: 'kraken', value: 'The kraken command'},
            {name: 'djs', value: 'Sends the link for discord.js, the code used for the bot'},
            {name: 'djsguide', value: 'Sends a link to the Discord.js guide'},
            {name: 'spaceacelinks', value: 'Sends an embed with all my links!'},
            {name: 'youtube', value: 'Sends a link for my youtube channel'},
            {name: 'creator', value: 'Tells you who the creator of Jebediah Kerman is'},
            {name: 'starbase-games', value: 'Gives information on popular starbase games!'}
        )

        message.channel.send(newEmbed);
    }
}