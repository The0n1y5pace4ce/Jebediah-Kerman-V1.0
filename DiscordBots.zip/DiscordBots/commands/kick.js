module.exports = {
    name: 'kick',
    description: "Kick members",
    execute(message, args) {

        let role = message.guild.roles.cache.find(r => r.name === 'Moderator');

        if(message.member.roles.cache.has('868984164131667978')){
            const memberTarget = message.mentions.members.first();
            memberTarget.kick();
            message.channel.send('User Kicked');
        }
        else{
            message.channel.send('You do not have correct perms to kick members');
        }
    }
}