module.exports = {
    name: 'addonsbyace',
    description: "Sends the links to addons for KSP made by TheSpaceAce",
    execute(message, args, Discord) {
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#baf123')
        .setTitle('Kerbal Space Program Addons Made By TheSpaceAce')
        .setDescription('These are addons and mods for KSP made by TheSpaceAce, they include realname configs for popular KSP mods, as well as TUFX profiles')
        .addFields(
            {name: 'TUFX Profiles', value: 'https://github.com/The0n1y5pace4ce/Estreet-rockets3x-real-names'},
            {name: 'EstreetRocket3x Realnames', value: 'https://github.com/The0n1y5pace4ce/Estreet-rockets3x-real-names'},
            {name: 'Boring Crew Services Realnames', value: 'https://github.com/The0n1y5pace4ce/Boring-Realnames'},
            {name: 'SEP Realnames', value: 'https://github.com/The0n1y5pace4ce/SEP-Realnames'}
        )
        message.channel.send(newEmbed);
    }
}