module.exports = {
    name: 'help-moderation',
    description: "none",
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Jebediah Moderation Commands')
        .setDescription('Jebediah Kerman moderation commands (only works for mods)')
        .addFields(
            {name: 'ban', value: 'Bans Users From The Server'},
            {name: 'Mute and unmute', value: 'Mutes and unmutes members'},
            {name: 'kick', value: 'Kicks Users from the server'},
            {name: 'say <channel> <content>', value: 'Allows you to make the bot send messages in another channel'},
            {name: 'status', value: 'Changes the bots status'},
        )

        message.channel.send(newEmbed);
    }
}