module.exports = {
    name: 'creator',
    description: "Tells you who the creator of Jebediah Kerman is",
    execute(message, args, Discord){
        const creatorEmbed = new Discord.MessageEmbed()
        .setColor('RANDOM')
        .setTitle('The creator of Jebediah Kerman is TheSpaceAce#2107')
        .setAuthor(`Requested by ${message.author.tag}`)
        .setDescription('Other devs of the bot: None as of now!')
        .setTimestamp()

        message.channel.send(creatorEmbed)
    }
}