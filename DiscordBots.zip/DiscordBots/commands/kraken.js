module.exports = {
    name: 'kraken',
    description: "this will tell you advice on the kraken",
    execute(message, args){
        message.channel.send('skill issue')
    }
}