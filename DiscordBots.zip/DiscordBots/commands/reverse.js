module.exports = {
	name: 'reverse',
	description: 'Reverse a text',
	execute: (message, args) => {
        if (args.length < 1) {
			message.reply('You must input text to be reversed!');
			return;
		}
		message.reply(`${args.join(' ').split('').reverse().join('')}`);
    }
}
