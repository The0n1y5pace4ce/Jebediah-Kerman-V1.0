module.exports = {
    name: 'help-fun',
    description: 'none',
    execute(message, args, Discord){
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#0EA226')
        .setTitle('Jebediah Fun Commands')
        .setDescription('Jebediah Kerman fun commands')
        .addFields(
            {name: '8ball <question>', value: 'An 8ball command, ask it any question and it will give you an answer (the question is not optional, or it will not work)'},
            {name: 'diceroll', value: 'Roll a dice!'},
            {name: 'hangman', value: 'Play hangman in discord!'},
            {name: 'jokebezos', value: 'Sends a joke against jeff bezos!'},
            {name: 'coinflip', value: 'Flips a coin!'},
            {name: 'guessthenumber', value: 'A guess the number command (1-100), only for <#926260139961503764>'},
        )

        message.channel.send(newEmbed);
    }
}