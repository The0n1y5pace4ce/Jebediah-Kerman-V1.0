const Discord = require('discord.js');

const client = new Discord.Client();

const prefix = '#';

const fs = require('fs');

client.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
    const command = require(`./commands/${file}`);

    client.commands.set(command.name, command);
}

client.once('ready', () => {
    console.log('Jeb Is Online!');
});

client.on('guildMemberAdd', guildMember =>{
    let welcomeRole = guildMember.guild.roles.cache.find(role => role.name === 'Space Person');

    guildMember.roles.add(welcomeRole);
    guildMember.guild.channels.cache.get('868979279914999810').send(`Welcome To The Space Lounge <@${guildMember.user.id}> Be Sure To Read The Rules at <#919029726432067584> Carefully!`);
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'ping'){
        client.commands.get('ping').execute(message, args);
    }
    else if(command === 'dvjnsq'){
        client.commands.get('dvjnsq').execute(message, args, Discord);
    }
    else if(command === 'dvrss'){
        client.commands.get('dvrss').execute(message, args, Discord);
    }
    else if(command === 'dvstock'){
        client.commands.get('dvstock').execute(message, args, Discord);
    }
    else if(command === 'invite'){
        client.commands.get('invite').execute(message, args, Discord);
    }
    else if(command === 'kraken'){
        client.commands.get('kraken').execute(message, args, Discord);
    }
    else if(command === 'spaceacemods'){
        client.commands.get('spaceacemods').execute(message, args, Discord);
    }
    else if(command === 'youtube'){
        client.commands.get('youtube').execute(message, args, Discord)
    }
    else if(command === 'help'){
        client.commands.get('help').execute(message, args, Discord);
    }
    else if(command === 'help2'){
        client.commands.get('help2').execute(message, args, Discord);
    }
    else if(command == 'kick'){
        client.commands.get('kick').execute(message, args, client, Discord);
    }
    else if(command === 'ban'){
        client.commands.get('ban').execute(message, args, client, Discord);
    }
    else if(command === 'dvgpp'){
        client.commands.get('dvgpp').execute(message, args, Discord);
    }
    else if(command === 'kspkeybinds'){
        client.commands.get('kspkeybinds').execute(message, args, Discord);
    }
    else if(command === 'spaceacelinks'){
        client.commands.get('spaceacelinks').execute(message, args, Discord);
    }
    else if(command === 'djs'){
        client.commands.get('djs').execute(message, args, Discord);
    }
    else if(command === 'djsguide'){
        client.commands.get('djsguide').execute(message, args, Discord);
    }
    else if(command === 'kspforums'){
        client.commands.get('kspforums').execute(message, args, Discord);
    }
    else if(command === 'kspmods'){
        client.commands.get('kspmods').execute(message, args, Discord);
    }
    else if(command === 'dvksrss'){
        client.commands.get('dvksrss').execute(message, args, Discord);
    }
    else if(command === 'vismodsdecide'){
        client.commands.get('vismodsdecide').execute(message, args, Discord);
    }
    else if(command === 'addonsbyace'){
        client.commands.get('addonsbyace').execute(message, args, Discord);
    }
    else if(command === 'creator'){
        client.commands.get('creator').execute(message, args, Discord);
    }
    else if(command === '8ball'){
        client.commands.get('8ball').execute(message, args);
    }
    else if(command === 'embed'){
        client.commands.get('embed').execute(message, args, client);
    }
    else if(command === 'avatar'){
        client.commands.get('avatar').execute(message, args, client,);
    }
    else if(command === 'mute'){
        client.commands.get('mute').execute(message, args, client, Discord);
    }
    else if(command === 'unmute'){
        client.commands.get('unmute').execute(message, args, Discord);
    }
    //else if(command === 'weather'){
        //client.commands.get('weather').execute(message, args, client);
    //}
    else if(command === 'say'){
        client.commands.get('say').execute(message, args, client);
    }
    else if(command === 'status'){
        client.commands.get('status').execute(message, args, client, Discord);
    }
    else if(command === 'guessthenumber'){
        client.commands.get('guessthenumber').execute(message, args, client);
    }
    else if(command === 'urban'){
        client.commands.get('urban').execute(message, args, client);
    }
    else if(command === 'advice'){
        client.commands.get('advice').execute(message, args, client);
    }
    else if(command === 'coinflip'){
        client.commands.get('coinflip').execute(message, args, client);
    }
    else if(command === 'random-urban'){
        client.commands.get('random-urban').execute(message, args, client);
    }
    else if(command === 'diceroll'){
        client.commands.get('diceroll').execute(message, args, client);
    }
    else if(command === 'hangman'){
        client.commands.get('hangman').execute(message, args, client);
    }
    else if(command === 'jokebezos'){
        client.commands.get('joke').execute(message, args, client);
    }
    else if(command === 'poll'){
        client.commands.get('poll').execute(message, args);
    }
    else if(command === 'reverse'){
        client.commands.get('reverse').execute(message, args);
    }
    else if(command === 'serverinfo'){
        client.commands.get('serverinfo').execute(message, args);
    }
    else if(command === 'userinfo'){
        client.commands.get('userinfo').execute(message, args);
    }
    else if(command === 'latency'){
        client.commands.get('latency').execute(message, args);
    }
    else if(command === 'help-fun'){
        client.commands.get('help-fun').execute(message, args, Discord);
    }
    else if(command === 'help-ksp'){
        client.commands.get('help-ksp').execute(message, args, Discord);
    }
    else if(command === 'help-moderation'){
        client.commands.get('help-moderation').execute(message, args, Discord);
    }
    else if(command === 'help-utility'){
        client.commands.get('help-utility').execute(message, args, Discord);
    }
    else if(command === 'help-other'){
        client.commands.get('help-other').execute(message, args, Discord);
    }
    else if(command === 'wiki'){
        client.commands.get('wiki').execute(message, args, Discord);
    }
    else if(command === 'search'){
        client.commands.get('search').execute(message, args, Discord);
    }
    else if(command === 'starbase-games'){
        client.commands.get('starbase-games').execute(message, args, Discord);
    }
});

client.login(token);